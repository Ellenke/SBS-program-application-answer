function RK4
 
clear;clc;
% define initial values
E0=1;  
k3=150/60;   
 
% define step width and initial values of ES,S
h=0.001;        % step width is 0.001s
t=0:h:30;       % range is 0-30s
n=length(t);   % quantity of t
Y(1,1)=0;     % initial values of ES put in matrix Y
Y(2,1)=10;      % initial values of S put in matrix Y
 
% define RK4 to find out the solution of S and ES
for k=1:n-1  
    z1=f(t(k),Y(1:2,k));  % Y(1:2,k) means take the 1st and 2nd row of kth line
    z2=f(t(k)+h/2,Y(1:2,k)+z1*h/2);
    z3=f(t(k)+h/2,Y(1:2,k)+z2*h/2);
    z4=f(t(k)+h,Y(1:2,k)+z3*h);
    Y(1:2,k+1)=Y(1:2,k)+h*(z1+2*z2+2*z3+z4)/6; % iteration of Y 
                                               % new ES/S will be added into matrix Y
                                               % ES to the 1st row, S to the 2nd row
end
ES=Y(1,:);  % Y's 1st row
S=Y(2,:);  % Y's 2nd row
 
%solution to E and P
E=E0-ES;
 
for i=1:1:n  % initial value: step width: final value
    P(i)=k3*sum(ES(1:i))*h;  % P is the integration of ES, ES is discrete
                            % P(0) = 0
                            % so Pi is the sumption of ES1-ESi * step wid
end
 
Vp=k3.*ES; % Vp is the change rate of P
          % n2.means conduct every element in matrix
 
% plot
figure(1);  % 1st picture
plot(t,E,t,S,t,ES,t,P,'LineWidth',3);  % x:t y:E,S,ES,P
legend('E','S','ES','P');  
title('Variation of Components Concentration');
xlabel('time/s');
ylabel('concentration/uM');
 
figure(2);  % 2nd picture
plot(t,Vp,t,S,'LineWidth',3);  % x:t y:Vp,S
legend('Vp','S');
title('Variation of Vp and S');
xlabel('time/s');
 
figure(3);  % 3rd picture
plot(S,Vp,'LineWidth',3);  % x:s y:Vp
title('Vp changed with the concentration of S');
xlabel('Sconcentration/uM');
ylabel('uM/s');
 
end