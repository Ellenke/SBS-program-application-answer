function F=f(t,Y)  
% input t and matrix Y
% define variables
k1=100/60;
k2=600/60;
k3=150/60;
E0=1;
theta=k2+k3;
lamda=k1*E0;
 
% define the equation we want to solve
ES=Y(1,1);  % Y is a 1*2 matrix
S=Y(2,1); 
f1=lamda*S-(theta+k1*S)*ES;  % equation of dES/dt
f2=-lamda*S+(k1*S+k2)*ES;  % equation of dS/dt
F=[f1;f2];  % output of F is a matrix contain f1(ES) and f2(S)
end